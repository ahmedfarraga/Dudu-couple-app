package com.dudu.app

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File

// ====== Cloudinary config
// Cloud name and unsigned upload preset from console.cloudinary.com
private const val CLOUDINARY_CLOUD_NAME = "sdv4tsw0"
private const val CLOUDINARY_UPLOAD_PRESET = "dudu_memories"

private val httpClient = OkHttpClient()

/**
 * Uploads an image picked from the gallery to Cloudinary using the
 * unsigned upload preset, and returns the resulting public URL, or
 * null if the upload failed.
 */
suspend fun uploadImageToCloudinary(
    context: Context,
    imageUri: Uri,
): String? =
    withContext(Dispatchers.IO) {
        try {
            // Copy the picked content:// Uri into a temp file OkHttp can stream
            val tempFile = File.createTempFile("upload", ".jpg", context.cacheDir)
            context.contentResolver.openInputStream(imageUri)?.use { input ->
                tempFile.outputStream().use { output -> input.copyTo(output) }
            }

            val requestBody =
                MultipartBody
                    .Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("upload_preset", CLOUDINARY_UPLOAD_PRESET)
                    .addFormDataPart(
                        "file",
                        tempFile.name,
                        tempFile.asRequestBody("image/*".toMediaTypeOrNull()),
                    ).build()

            val request =
                Request
                    .Builder()
                    .url("https://api.cloudinary.com/v1_1/$CLOUDINARY_CLOUD_NAME/image/upload")
                    .post(requestBody)
                    .build()

            httpClient.newCall(request).execute().use { response ->
                tempFile.delete()
                if (!response.isSuccessful) return@withContext null
                val body = response.body?.string() ?: return@withContext null
                JSONObject(body).optString("secure_url").takeIf { it.isNotBlank() }
            }
        } catch (e: Exception) {
            null
        }
    }
