package com.dudu.app

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.google.firebase.firestore.firestore
import com.google.firebase.Firebase
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

data class MemoryItem(
    val id: String = "",
    val title: String = "",
    val photoUrl: String = "",
    val date: String = "",
)

@Composable
fun MemoriesScreen(
    coupleId: String,
    onBack: () -> Unit,
) {
    val db = remember { Firebase.firestore }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var memories by remember { mutableStateOf<List<MemoryItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var showAddDialog by remember { mutableStateOf(false) }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var newTitle by remember { mutableStateOf("") }
    var isUploading by remember { mutableStateOf(false) }

    fun reload() {
        scope.launch {
            isLoading = true
            val snapshot =
                db
                    .collection("couples")
                    .document(coupleId)
                    .collection("memories")
                    .orderBy("date")
                    .get()
                    .await()
            memories =
                snapshot.documents.map { doc ->
                    MemoryItem(
                        id = doc.id,
                        title = doc.getString("title") ?: "",
                        photoUrl = doc.getString("photoUrl") ?: "",
                        date = doc.getString("date") ?: "",
                    )
                }
            isLoading = false
        }
    }

    LaunchedEffect(coupleId) { reload() }

    val imagePicker =
        rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                pickedUri = uri
                showAddDialog = true
            }
        }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            TextButton(onClick = onBack) { Text("\u2190 Back") }
            Text("Our Memories \uD83D\uDCF7", style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = { imagePicker.launch("image/*") }) { Text("+ Add") }
        }

        androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(12.dp))

        if (isLoading) {
            CircularProgressIndicator()
        } else if (memories.isEmpty()) {
            Text("No memories yet \u2014 add your first one!")
        } else {
            LazyColumn {
                items(memories) { memory ->
                    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                        AsyncImage(
                            model = memory.photoUrl,
                            contentDescription = memory.title,
                            modifier = Modifier.fillMaxWidth().height(200.dp),
                            contentScale = ContentScale.Crop,
                        )
                        Text(text = memory.title, style = MaterialTheme.typography.titleMedium)
                        Text(text = memory.date, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    if (showAddDialog && pickedUri != null) {
        AlertDialog(
            onDismissRequest = { if (!isUploading) showAddDialog = false },
            title = { Text("New memory") },
            text = {
                Column {
                    AsyncImage(
                        model = pickedUri,
                        contentDescription = null,
                        modifier = Modifier.fillMaxWidth().height(160.dp),
                        contentScale = ContentScale.Crop,
                    )
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        placeholder = { Text("Title, e.g. \"Our first date\"") },
                    )
                    if (isUploading) {
                        androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
                        CircularProgressIndicator()
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = !isUploading && newTitle.isNotBlank(),
                    onClick = {
                        val uri = pickedUri ?: return@Button
                        isUploading = true
                        scope.launch {
                            val url = uploadImageToCloudinary(context, uri)
                            if (url != null) {
                                db
                                    .collection("couples")
                                    .document(coupleId)
                                    .collection("memories")
                                    .add(
                                        mapOf(
                                            "title" to newTitle,
                                            "photoUrl" to url,
                                            "date" to java.time.LocalDate.now().toString(),
                                        ),
                                    ).await()
                                reload()
                            }
                            isUploading = false
                            showAddDialog = false
                            newTitle = ""
                            pickedUri = null
                        }
                    },
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(
                    enabled = !isUploading,
                    onClick = {
                        showAddDialog = false
                        newTitle = ""
                        pickedUri = null
                    },
                ) { Text("Cancel") }
            },
        )
    }
}
